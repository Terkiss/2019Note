﻿using System;

namespace AI.NuRONetwork
{
    public class Class1
    {
        public Class1()
        {
        }
    }

}