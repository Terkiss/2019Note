﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JeongLIbrary.Data_Structor
{
    public class JeongQueueNode<T>
    {
        public T Data;
        public JeongQueueNode<T> Next;
    }
}
