﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JeongLIbrary.Data_Structor
{

    public class JeongRedBlackTree<T>
    {
    }
}
