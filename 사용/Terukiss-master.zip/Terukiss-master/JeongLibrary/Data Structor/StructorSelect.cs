﻿public enum Data_Structure
{
    LinkedList,
    DoubleLinkedList,
    Queue,
    Stack,
    Tree,
    RedBlackTree,
    ValTree

}