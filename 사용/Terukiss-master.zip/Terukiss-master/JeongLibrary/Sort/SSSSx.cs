﻿using System;
using System.Collections.Generic;


namespace JeongLIbrary
{ 
public static class SSSSx
{
    // 확장 메소드
    public static bool EmpTy( this Stack<int> stk )
    { 
        if (stk.Count == 0)
        {
            //return true;
            return true;
        }
        else
        {
            // return false;S
            return false;
        }
    }
   
}
}