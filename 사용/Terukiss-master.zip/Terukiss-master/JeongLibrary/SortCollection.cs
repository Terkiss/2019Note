﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JeongLibrary
{
    class SortCollection
    {
    }
}
