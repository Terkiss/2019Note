package com.cyberkyj.chap08;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
