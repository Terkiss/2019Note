package com.cyberkyj.implicit_intent_ex;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
